<!DOCTYPE html>

<html>
<head>

	<meta charset=utf-8 />


	<title>LANDING PAGE</title>
	<meta name="google-site-verification" content="zQd8pef_mazi8KBab_uSbTF8BsxNJAE62AUWO2hgUho" />
	<meta name="description" content="Jimmy Tidey - Product Manager and Creative Technologist" />
	

	<link rel="stylesheet" type="text/css" media="screen" href="css/main.css" />
	
	<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
	<link rel="icon" type="image/x-icon" href="/favicon.ico" />
	
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.5.min.js"></script>
    
    <script>

    
    </script>
    
<head>
    
<body id='v3'>
    <div id='container'>        
        <div id='news_ticker'>
            <div id='news_ticker_content'>
                <ul>
                    <li class='ticker_item'>Competition: China Wine Awards 2012</li>
                    <li class='ticker_item'>Competition: China Wine Awards 2012</li>
                    <li class='ticker_item'>Competition: China Wine Awards 2012</li>
                    <li class='ticker_item'>Competition: China Wine Awards 2012</li>
                    <li class='ticker_item'>Competition: China Wine Awards 2012</li>
                </ul>
            </div>
            <img src='resources/pause.png' id='pause' />
            <span id='next_news'> &raquo;</span>
        </div>
	</div>
</body>
</html>
